import java.awt.*;

public interface Component {
    public void draw(Graphics g);
}
