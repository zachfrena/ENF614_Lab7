#include <iostream>
#include <string>
#include <vector>
using namespace std;


#ifndef User_HPP
#define User_HPP

typedef struct User{
public:
string username;
string password;

}User;
#endif